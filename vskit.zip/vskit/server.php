<?php

$localhost = 'localhost';
$user = 'root';
$pass = '';
$db = 'skitgram';

$conn = mysqli_connect($localhost, $user, $pass, $db);

if(!$conn)
{
    die(error);
}

$username = "";
$errors = array(); 
session_start();

if(isset($_POST['join']))
{
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

  $user_check_query = "select * from users where username='$username' limit 1";
  $result = mysqli_query($conn, $user_check_query);
  $user = mysqli_fetch_assoc($result);
  
  if ($user) { 
    if ($user['username'] === $username) {
        echo "<div align='center'>Username already exists</div>";
      array_push($errors, "Username already exists");
    }
}


   if (count($errors) == 0) {
  	$password =  password_hash($password, PASSWORD_DEFAULT);//encrypt the password before saving in the database

  	$query = "insert into users(username, password) values('$username', '$password')";
  	mysqli_query($conn, $query);
  	$_SESSION['username'] = $username;
  	$_SESSION['success'] = "You are now logged in";
  	header('location: index.php');
  }
}


//login
if (isset($_POST['login'])) {
  $username = mysqli_real_escape_string($conn, $_POST['username']);
  $password = mysqli_real_escape_string($conn, $_POST['password']);


  if (count($errors) == 0) {
    $query = "select * from users where username='$username'";
    $results = mysqli_query($conn, $query);
    while ($row = mysqli_fetch_assoc($results)){
    $password = password_verify($password, $row['password']);
    $nq = "select * from users where username='$username' and password='$password'";
    $rr = mysqli_query($conn, $query);
    if(mysqli_num_rows($rr)==1){
      $_SESSION['username'] = $username;
      $_SESSION['success'] = "You are now logged in";
      header('location: index.php');
    }
    else {
      echo "<div align='center'>Wrong information</div>";
      array_push($errors, "Wrong username/password combination");
    }
  }
  }
}
?>