<?php include "server.php";
?>
<!DOCTYPE html>
<html>
<title>SkitGram</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/w3.css">
<style>
.tabs {display:none;}
</style>
<body>

<nav class="w3-sidenav w3-black w3-card-2" style="width:130px">
  <div class="w3-container">
    <h5>Menu</h5>
  </div>
  <a href="#" class="tablink" onclick="openTab(event, 'Home')">Home</a>		
  <a href="#" class="tablink" onclick="openTab(event, 'Upload')">Upload</a>		
  <a href="#" class="tablink" onclick="openTab(event, 'Account')">Account</a>
</nav>

<div style="margin-left:130px">

  <div id="Home" class="w3-container tabs w3-animate-left">
    <div class="w3-card-4 w3-margin" style="width:50%;">
 
<header class="w3-container w3-blue">
  <h1>Header</h1>
</header>

<div class="w3-container">
  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
  <p><button class="w3-btn w3-dark-grey">Button</button></p>
</div>
  </div>
  </div>

  <div id="Upload" class="w3-container tabs w3-animate-opacity">
  <?php if(!isset($_SESSION['username']))
  {
      echo '
      <form class="w3-container" action="#" method="post">

<label>Username</label>
<input class="w3-input" type="text" name="username" required>

<label>Password</label>
<input class="w3-input" type="password"  name="password" required><br><br>
<button name="login" class="w3-btn w3-round-large">Login</button> OR <button name="join" class="w3-btn w3-round-large">Register</button>

</form>';
  }
  else {
      
    echo '<h2>Upload</h2>
    <p>Paris is the capital of France.</p> 
    <p>The Paris area is one of the largest population centers in Europe, with more than 12 million inhabitants.</p>
  </div>';
  }
  ?>
  </div>
  </div>
  <div id="Account" class="tabs w3-animate-opacity">
   <?php if(!isset($_SESSION['username']))
  {
 echo '
      <form class="w3-container" action="#" method="post">

<label>Username</label>
<input class="w3-input" type="text" name="username" required>

<label>Password</label>
<input class="w3-input" type="password"  name="password" required><br><br>
<button name="login" class="w3-btn w3-round-large">Login</button> OR <button name="join" class="w3-btn w3-round-large">Register</button>

</form>';
  }
  else {
    $username = $_SESSION['username'];
$qq = "select *  from users where username = '$username'";
$dd = mysqli_query($conn, $qq);
while ($row = mysqli_fetch_assoc($dd))
{
  extract($row);
}
echo'


<div class="w3-container">
  <p>'.$username.'</p>
  <hr>
  <img src="img_avatar3.png" alt="Avatar" class="w3-left w3-circle">
  <p>President/CEO at Mighty Schools...</p><br>
  <p class="w3-tooltip">Followers
<span style="position:absolute;left:0;bottom:18px"
class="w3-text w3-tag">9 million</span></p>
</div>

<button class="w3-btn-block w3-dark-grey">+ Follow</button>
</div>
</div>';
  }
?>
  </div>

</div>



<script src="js/script.js"></script>
</body>

</html>
